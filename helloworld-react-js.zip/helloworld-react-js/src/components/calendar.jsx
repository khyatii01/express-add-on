// import React, { useState } from "react";
// import Calendar from "react-calendar";
// import "react-calendar/dist/Calendar.css";
// import EventForm from "./event";
// import monthThemes from "./theme";

// const CustomCalendar = () => {
//   const [selectedDate, setSelectedDate] = useState(null);
//   const [showForm, setShowForm] = useState(false);
//   const [events, setEvents] = useState([]);
//   const [activeMonthIndex, setActiveMonthIndex] = useState(new Date().getMonth());

//   const theme = monthThemes[activeMonthIndex] || {};

//   const handleDateClick = (date) => {
//     setSelectedDate(date);
//     setShowForm(true);
//   };

//   const handleFormClose = () => {
//     setShowForm(false);
//     setSelectedDate(null);
//   };

//   const handleSaveEvent = (newEvent) => {
//     setEvents((prevEvents) => [...prevEvents, newEvent]);
//     console.log("Saved Event:", newEvent);
//   };

//   const handleMonthChange = ({ activeStartDate }) => {
//     const newMonth = activeStartDate.getMonth();
//     setActiveMonthIndex(newMonth);
//   };

//   return (
//     <div
//       className="calendar-wrapper"
//       style={{
//         backgroundColor: theme.backgroundColor,
//         color: theme.textColor,
//         padding: "1rem",
//         borderRadius: "1rem",
//         minHeight: "100vh",
//         transition: "all 0.4s ease-in-out",
//       }}
//     >
//       <h1 className="month-heading">{theme.title}</h1>
//       <p className="month-note">{theme.welcomeNote}</p>

//       <Calendar
//         onClickDay={handleDateClick}
//         onActiveStartDateChange={handleMonthChange}
//         className="react-calendar"
//         tileClassName={({ date }) => {
//           const hasEvent = events.some((e) => e.date === date.toDateString());
//           return hasEvent ? "has-event" : null;
//         }}
//       />

//       {showForm && selectedDate && (
//         <EventForm
//           date={selectedDate}
//           onClose={handleFormClose}
//           onSave={handleSaveEvent}
//         />
//       )}
//     </div>
//   );
// };

// export default CustomCalendar;
// import React, { useState } from "react";
// import Calendar from "react-calendar";
// import "react-calendar/dist/Calendar.css";
// import EventForm from "./event";
// import monthThemes from "./theme";
// import "./calendarStyles.css"; // styles for tiles



// const CustomCalendar = () => {
//   const [selectedDate, setSelectedDate] = useState(null);
//   const [showForm, setShowForm] = useState(false);
//   const [events, setEvents] = useState([]);
//   const [activeMonthIndex, setActiveMonthIndex] = useState(new Date().getMonth());

//   const theme = monthThemes[activeMonthIndex] || {};

//   const handleDateClick = (date) => {
//     setSelectedDate(date);
//     setShowForm(true);
//   };

//   const handleFormClose = () => {
//     setShowForm(false);
//     setSelectedDate(null);
//   };

//   const handleSaveEvent = (newEvent) => {
//     setEvents((prevEvents) => [...prevEvents, newEvent]);
//     console.log("Saved Event:", newEvent);
//   };

//   const handleMonthChange = ({ activeStartDate }) => {
//     const newMonth = activeStartDate.getMonth();
//     setActiveMonthIndex(newMonth);
//   };

//   return (
//     <div
//       className="calendar-wrapper"
//       style={{
//         backgroundColor: theme.backgroundColor,
//         color: theme.textColor,
//         padding: "2rem",
//         borderRadius: "1.5rem",
//         minHeight: "100vh",
//         transition: "all 0.4s ease-in-out",
//       }}
//     >
//       <h1 className="month-heading">{theme.title}</h1>
//       <p className="month-note">{theme.welcomeNote}</p>

//       <Calendar
//         onClickDay={handleDateClick}
//         onActiveStartDateChange={handleMonthChange}
//         className="react-calendar styled-calendar"
//         // tileClassName={({ date }) => {
//         //   const dateStr = date.toDateString();
//         //   const hasEvent = events.some((e) => e.date === dateStr);
//         //   const isSelected = selectedDate && selectedDate.toDateString() === dateStr;

//         //   if (hasEvent && isSelected) return "tile has-event selected-tile";
//         //   if (hasEvent) return "tile has-event";
//         //   if (isSelected) return "tile selected-tile";
//         //   return "tile normal-tile";
//         // }}
//         tileClassName={({ date }) => {
//   const hasEvent = events.some((e) => {
//     const eventDate = new Date(e.date);
//     return (
//       eventDate.getDate() === date.getDate() &&
//       eventDate.getMonth() === date.getMonth() &&
//       eventDate.getFullYear() === date.getFullYear()
//     );
//   });

//   const isSelected =
//     selectedDate &&
//     selectedDate.getDate() === date.getDate() &&
//     selectedDate.getMonth() === date.getMonth() &&
//     selectedDate.getFullYear() === date.getFullYear();

//   if (hasEvent && isSelected) return "tile has-event selected-tile";
//   if (hasEvent) return "tile has-event";
//   if (isSelected) return "tile selected-tile";
//   return "tile normal-tile";
// }}

//       />

//       {showForm && selectedDate && (
//         <EventForm
//           date={selectedDate}
//           onClose={handleFormClose}
//           onSave={handleSaveEvent}
//         />
//       )}
//     </div>
//   );
// };

// export default CustomCalendar;
import React, { useState, useEffect } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import EventForm from "./event";
import TaskListView from "./TaskListView";
import monthThemes from "./theme";
import "./calendarStyles.css";

const CustomCalendar = () => {
  const [selectedDate, setSelectedDate] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [showListView, setShowListView] = useState(false);
  const [activeMonthIndex, setActiveMonthIndex] = useState(new Date().getMonth());
  const [tasks, setTasks] = useState([]);

  const theme = monthThemes[activeMonthIndex] || {};

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("events")) || [];
    setTasks(saved);
  }, []);

  const handleDateClick = (date) => {
    const dateStr = date.toDateString();
    setSelectedDate(date);
    const hasTasks = tasks.some((task) => task.date === dateStr);
    setShowForm(!hasTasks);
    setShowListView(hasTasks);
  };

  const handleFormClose = () => {
    setShowForm(false);
    setShowListView(false);
    setSelectedDate(null);
  };

  const handleSaveEvent = (newEvent) => {
    const updated = [...tasks, newEvent];
    setTasks(updated);
    localStorage.setItem("events", JSON.stringify(updated));
    setShowForm(false);
    setShowListView(true);
  };

  const handleMonthChange = ({ activeStartDate }) => {
    setActiveMonthIndex(activeStartDate.getMonth());
  };

  const tasksForSelectedDate = tasks.filter(
    (task) => task.date === (selectedDate && selectedDate.toDateString())
  );

  return (
    <div
      className="calendar-wrapper"
      style={{
        backgroundColor: theme.backgroundColor,
        color: theme.textColor,
        padding: "2rem",
        borderRadius: "1.5rem",
        minHeight: "100vh",
        transition: "all 0.4s ease-in-out",
        position: "relative",
      }}
    >
      <h1 className="month-heading">{theme.title}</h1>
      <p className="month-note">{theme.welcomeNote}</p>

      <Calendar
        onClickDay={handleDateClick}
        onActiveStartDateChange={handleMonthChange}
        className="react-calendar styled-calendar"
        tileClassName={({ date }) => {
          const dateStr = date.toDateString();
          const hasEvent = tasks.some((e) => new Date(e.date).toDateString() === dateStr);
          const isSelected = selectedDate && selectedDate.toDateString() === dateStr;
          if (hasEvent && isSelected) return "tile has-event selected-tile";
          if (hasEvent) return "tile has-event";
          if (isSelected) return "tile selected-tile";
          return "tile normal-tile";
        }}
      />

      {selectedDate && showForm && (
        <EventForm
          date={selectedDate}
          onClose={handleFormClose}
          onSave={handleSaveEvent}
        />
      )}

      {selectedDate && showListView && (
        <TaskListView
          tasks={tasksForSelectedDate}
          date={selectedDate}
          onClose={handleFormClose}
          setTasks={setTasks}
        />
      )}
    </div>
  );
};

export default CustomCalendar;
