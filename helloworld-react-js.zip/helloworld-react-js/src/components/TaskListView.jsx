import React, { useState } from "react";
import "./taskOverlay.css";
import EventForm from "./event"; // ✅ Import your form

const TaskOverlay = ({ tasks, date, onClose, setTasks }) => {
  const [showForm, setShowForm] = useState(false); // for showing EventForm

//   const handleSave = (newTask) => {
//     // Save logic here (you can extend this)
//     console.log("Saved task:", newTask);
//   };
   const handleSave = (newTask) => {
  setTasks((prevTasks) => [...prevTasks, newTask]);
  setShowForm(false);
};

  const handleCreate = () => {
    console.log("Start Creating clicked"); // or extend logic
  };

  return (
    <div className="task-overlay">
      <div className="task-overlay-content">
        <button className="close-btn" onClick={onClose}>×</button>
        <h2>Tasks for {date.toDateString()}</h2>

        <button
          className="add-btn"
          onClick={() => setShowForm(true)}
          style={{
            float: "right",
            marginBottom: "1rem",
            fontSize: "1.2rem",
            background: "transparent",
            border: "none",
            cursor: "pointer",
            color: "#ff6699",
          }}
        >
          ➕
        </button>

        {tasks.length > 0 ? (
          <table className="task-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Event</th>
                <th>Platform</th>
              </tr>
            </thead>
            <tbody>
              {tasks.map((task, index) => (
                <tr key={task.id}>
                  <td>{index + 1}</td>
                  <td>{task.caption}</td>
                  <td>{task.platform || "TBD"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No tasks found.</p>
        )}
      </div>

      {/* ✅ Show EventForm as a new layer */}
      {showForm && (
        <EventForm
          date={date}
          onClose={() => setShowForm(false)}
          onSave={handleSave}
          onCreate={handleCreate}
        />
      )}
    </div>
  );
};

export default TaskOverlay;
