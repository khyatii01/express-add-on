// monthThemes.jsx

const monthThemes = {
  0: {
    title: "January — Fresh Starts ❄️",
    welcomeNote: "New year, new ideas. Time to design your dreams.",
    backgroundColor: "#DFF3FC",
    textColor: "#0A2F4F",
  },
  1: {
    title: "February — Love & Expression 💌",
    welcomeNote: "Craft heartfelt content and express your story.",
    backgroundColor: "#FFE6EC",
    textColor: "#5E1A26",
  },
  2: {
    title: "March — Fresh Vibes 🌿",
    welcomeNote: "Let your creativity bloom like spring flowers.",
    backgroundColor: "#E4FBE5",
    textColor: "#1F4B27",
  },
  3: {
    title: "April — Playful Palette 🎨",
    welcomeNote: "Experiment with color and break out of the ordinary.",
    backgroundColor: "#FFF4E0",
    textColor: "#5E3200",
  },
  4: {
    title: "May — Momentum & Growth 🚀",
    welcomeNote: "Keep your content growing and glowing.",
    backgroundColor: "#E0F7FA",
    textColor: "#004D40",
  },
  5: {
    title: "June — Summer Flow ☀️",
    welcomeNote: "Bask in warmth and let creativity flow freely.",
    backgroundColor: "#FFFDE7",
    textColor: "#795548",
  },
  6: {
    title: "July — Bold Moves 🔥",
    welcomeNote: "Be bold with your visuals. Make a statement.",
    backgroundColor: "#FFEBEE",
    textColor: "#B71C1C",
  },
  7: {
    title: "August — Bright Horizons 🌅",
    welcomeNote: "Design with purpose. Inspire what's ahead.",
    backgroundColor: "#FFF3E0",
    textColor: "#BF360C",
  },
  8: {
    title: "September — Focus & Refine 📝",
    welcomeNote: "Polish your ideas into something impactful.",
    backgroundColor: "#E8EAF6",
    textColor: "#1A237E",
  },
  9: {
    title: "October — Spooky & Stylish 🦇",
    welcomeNote: "Have fun with spooky visuals and sharp contrasts.",
    backgroundColor: "#F3E5F5",
    textColor: "#4A148C",
  },
  10: {
    title: "November — Reflect & Connect 🤝",
    welcomeNote: "Craft meaningful content that resonates.",
    backgroundColor: "#FFF8E1",
    textColor: "#4E342E",
  },
  11: {
    title: "December — Wrap It Up 🎁",
    welcomeNote: "Celebrate your design journey and share joy.",
    backgroundColor: "#ECEFF1",
    textColor: "#263238",
  },
};

export default monthThemes;
