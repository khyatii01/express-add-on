import React, { useState } from "react";
import "./event.css"; // You’ll define styles here

const EventForm = ({ date, onClose, onSave, onCreate }) => {
  const [caption, setCaption] = useState("");
  const [platform, setPlatform] = useState("");
  const [description, setDescription] = useState("");
  const [inspo, setInspo] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    const newEvent = {
      date: date.toDateString(),
      caption,
      platform,
      description,
      inspo,
    };
    onSave(newEvent);
    onClose();
  };

  return (
    <div className="event-form-backdrop">
      <div className="event-form-container">
        <form onSubmit={handleSubmit} className="event-form">
          <label>
            Event Name:
            <input
              type="text"
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder="beach post"
              className="input-field"
              required
            />
          </label>

          <label>
            Platform:
            <input
              type="text"
              value={platform}
              onChange={(e) => setPlatform(e.target.value)}
              placeholder="Pinterest, etc."
              className="input-field"
              required
            />
          </label>

          <label>
            Description:
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="A vacation post...."
              className="textarea-field"
              rows="3"
            />
          </label>

          <label className="caption-label">
            Caption:
            <div className="caption-row">
              <input
                type="text"
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder="summer vibes.."
                className="input-field"
              />
              <button
                type="button"
                className="generate-btn"
                onClick={() => {
                  setCaption("Generated caption ✨"); // replace with logic if needed
                }}
              >
                ✨ Generate
              </button>
            </div>
          </label>

          <label>
            Templates:
            <input
              type="text"
              value={inspo}
              onChange={(e) => setInspo(e.target.value)}
              placeholder="#warm  #sunlight"
              className="input-field"
            />
          </label>

          <div className="form-actions">
            <button type="button" className="cancel-btn" onClick={onClose}>
              Cancel
            </button>
            <button type="button" className="save-btn" onClick={handleSubmit}>
              Save
            </button>
          </div>

          <div className="start-creating-wrapper">
            <button
              type="button"
              className="start-creating-btn"
              onClick={onCreate}
            >
              Start Creating
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EventForm;

